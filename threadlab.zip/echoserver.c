#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <errno.h>
#include <pthread.h>
#include <semaphore.h>


#define QLEN 5
#define BUFSIZE 4096
#define NUMTHREADS 5

int passivesock( char *service, char *protocol, int qlen, int *rport);
sem_t first;


pthread_mutex_t mutex ;
//http://pubs.opengroup.org/onlinepubs/7908799/xsh/pthread_cond_init.html
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

pthread_mutex_t mutex_admin;
pthread_cond_t cond_admin = PTHREAD_COND_INITIALIZER;

int msock; //main socket
int curr_num = 0;
int lnum = 1;

void *admin_thread( void *ign){
  char buf[BUFSIZE];
  struct sockaddr_in fsin;
  int alen;
  int ssock;
  int cc;
  char *out_s;
  alen = sizeof(fsin);
  ssock = accept(msock, (struct sockaddr *)&fsin, &alen );
  if (ssock < 0){
    fprintf(stderr, "accept: %s\n", strerror(errno) );
    exit(-1);
  }
  printf( "A client has arrived for echoes.\n" );
  fflush( stdout );
  out_s = "QS|ADMIN\r\n";
  write(ssock, out_s, strlen(out_s));
  while(1){
    if ( (cc = read(ssock, buf, BUFSIZE)) <= 0 ){
      printf("The client has gone.\n");
      close(ssock);
      break;
    }
    else{
      int i;
      char lnum_a[BUFSIZE];
      int count = 0;
      int lnum_count = 0;
      for(int i; i < cc;i++){
        if ( (count > 1) && (buf[i]) != '\r'){
          lnum_a[lnum_count] = buf[i];
          lnum_count++;
        }
        if (buf[i] == '|'){
          count++;
        }
      }
      lnum_a[lnum_count] = '\0';
      lnum = atoi(lnum_a);
      curr_num++;
      pthread_mutex_lock( &mutex_admin );
      pthread_cond_signal( &cond_admin);
      pthread_mutex_unlock( &mutex_admin );
      // sem_post( &first );
      out_s = "WAIT\r\n";
      if ( write( ssock, out_s, strlen(out_s)) < 0){
        close( ssock);
        break;
      }
      pthread_mutex_lock( &mutex );
      pthread_cond_wait( &cond, &mutex);
      pthread_mutex_unlock( &mutex );

    }
  }

}

void *thread_per_client( void *ign ){
  char buf[BUFSIZE];
  struct sockaddr_in fsin;
  int alen;
  int ssock; //client socket
  int cc;
  char *out_s;
  alen = sizeof(fsin);
  ssock = accept(msock, (struct sockaddr *)&fsin, &alen );
  if (ssock < 0){
    fprintf(stderr, "accept: %s\n", strerror(errno) );
    exit(-1);
  }
  printf( "A client has arrived for echoes.\n" );
	fflush( stdout );
  if (curr_num < lnum){
    out_s = "QS|JOIN\r\n";
    write(ssock, out_s, strlen(out_s));

    while(1){
      if ( (cc = read(ssock, buf, BUFSIZE)) <= 0 ){
        printf("The client has gone.\n");
        close(ssock);
        break;
      }
      else{
        out_s = "WAIT\r\n";
        if ( write( ssock, out_s, strlen(out_s)) < 0){
          close( ssock);
          break;
        }
        curr_num++;
        printf("Curr num:%i, curr lnum:%i\n", curr_num, lnum);

        if (curr_num == lnum ){
            pthread_mutex_lock( &mutex );
            printf("Before broadcast\n");
            //signal all threads that group is full
            pthread_cond_broadcast(&cond);
            printf("After broadcast\n");

            pthread_mutex_unlock( &mutex );
        } else {
            pthread_mutex_lock( &mutex );
            // block current thread untill signaled that all group is connected
            pthread_cond_wait( &cond, &mutex );
            pthread_mutex_unlock( &mutex );
        }


        close(ssock);
        break;
      }
    }
  } else{
    out_s = "QS|FULL\r\n";
    write(ssock, out_s, strlen(out_s));
    printf("The client has gone.\n");
    close(ssock);
  }

}


int main(int argc, char *argv[]){
  char * service; //port?
  sem_init( &first, 1, 1 );
  pthread_mutex_init( &mutex, NULL );
  pthread_mutex_init( &mutex_admin, NULL );


  int rport = 0; // shows whether port is set by OS


  switch (argc) {
    case 1:
      //OS chooses port and tells the user
      rport = 1;
      break;
    case 2:
      // use provided by user port
      service = argv[1];
      break;
    default:
      fprintf( stderr, "usage: server [port]\n" );
      exit(-1);
  }

  msock = passivesock( service, "tcp", QLEN, &rport);
  //rport after passivesock returns port set, if set by OS
  if (rport){
    printf("Server: port %i\n", rport);
    fflush( stdout);
  }

  pthread_t threads[NUMTHREADS];
  int status, i;
  pthread_mutex_lock( &mutex_admin );
  status = pthread_create( &threads[0], NULL, admin_thread, NULL );

  if (status != 0){
    printf( "pthread_create error %d.\n", status );
    exit( -1 );
  }
  printf("Waiting for the first\n");
  pthread_cond_wait( &cond_admin, &mutex_admin);
  printf("First is unlocked\n");

  pthread_mutex_unlock( &mutex_admin );
  for (i = 1; i < NUMTHREADS;i++){

    status = pthread_create( &threads[i], NULL, thread_per_client, NULL );

    if (status != 0){
      printf( "pthread_create error %d.\n", status );
			exit( -1 );
    }
  }

  for (i = 0; i < NUMTHREADS; i++)
    pthread_join( threads[i], NULL);
  pthread_exit( 0 );
}
